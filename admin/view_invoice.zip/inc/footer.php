<div class="col-md-12">
    <div class="copyright">
        <p>Copyright <a href="master_view_all_receipts.php">©</a> 2025 Firstchoice Superwheels Admin Manager <a href="https://www.pentagonware.com">Managed by - PENTAGONWARE TECHNOLOGIES</a>.</p>
    </div>
</div>
