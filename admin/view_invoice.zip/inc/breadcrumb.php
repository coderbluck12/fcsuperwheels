<!-- END BREADCRUMB-->
<section class="welcome p-t-10">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="title-4">Welcome back
                    <span><?php if(isset($full_name)) { echo $full_name; }?></span>
                </h1>
                <hr class="line-seprate">
            </div>
        </div>
    </div>
</section>
