<div class="row mt-4">
          <div class="col-md-12">
            <div class="au-breadcrumb-content">
              <div class="noprint">
                <a href="dashboard.php" class="btn btn-primary btn-sm m-2">Back to General Dashboard</a>
				<a href="master_view_all_receipts.php" class="btn btn-success btn-sm m-2">Master receipts manager</a>
                <a href="masternewreceipt.php" class="btn btn-warning btn-sm m-2">Generate New Master Receipt</a>
				<a href="invoice_manager.php" class="btn btn-danger btn-sm m-2">Invoice manager</a>
              </div>
            </div>
          </div>
        </div>