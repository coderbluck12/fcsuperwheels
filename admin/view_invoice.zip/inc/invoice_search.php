<!-- in place of inc/invoice_search.php -->
<div class="form-group mb-4" style="position:relative; max-width:300px;">
  <input
    id="searchInput"
    type="text"
    class="form-control"
    placeholder="Search receipts..."
    autocomplete="off"
  />
  <div id="briefInfo" class="mt-2 p-2 bg-white border rounded" style="display:none;"></div>
</div>
