<?php
include_once('inc/session_manager.php');
include_once('inc/functions.php');

// Fetching all receipts
$num_invoices_all    = $pdo->query("SELECT COUNT(*) FROM main_receipt WHERE visibility='yes'")->fetchColumn();
$num_invoices_paid   = $pdo->query("SELECT COUNT(*) FROM main_receipt WHERE payment_type='full' AND visibility='yes'")->fetchColumn();
$num_invoices_unpaid = $pdo->query("SELECT COUNT(*) FROM main_receipt WHERE payment_type='installment' AND visibility='yes'")->fetchColumn();
$num_admin           = $pdo->query("SELECT COUNT(*) FROM user")->fetchColumn();

if (isset($_GET['inf'])) {
  $comment = '<div class="alert alert-danger">Receipt number not found</div>';
}

// Prepare last-30-days data for line chart
$dates_last_30  = [];
$counts_last_30 = [];
for ($i = 29; $i >= 0; $i--) {
  $d = (new DateTime("-{$i} days"))->format('Y-m-d');
  $dates_last_30[]  = (new DateTime($d))->format('M j');
  $stmt = $pdo->prepare(
    "SELECT COUNT(*) 
       FROM main_receipt 
      WHERE visibility='yes' 
        AND DATE(time_created)=?"
  );
  $stmt->execute([$d]);
  $counts_last_30[] = (int)$stmt->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FC Superwheels Admin Manager</title>

  <!-- Bootstrap 4 -->
  <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet">
  <!-- FontAwesome -->
  <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet">
  <!-- Theme CSS -->
  <link href="css/theme.css" rel="stylesheet">
  <link href="css/navthing.css" rel="stylesheet">
  <!-- jQuery UI CSS for autocomplete -->
  <link
    rel="stylesheet"
    href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css"
  />
  <style>
    .page-content { background: #f7f7f7; padding: 2rem 0; }
    .inner-container { max-width: 1200px; margin: 0 auto; padding: 0 1rem; }
    .announcement {
      background: #38880B; color: #fff; border-radius: .5rem;
      padding: 1rem; margin-bottom: 1.5rem;
    }
    .stat-card {
      border: none; border-radius: .5rem;
      box-shadow: 0 .125rem .25rem rgba(0,0,0,.075);
      transition: transform .2s;
    }
    .stat-card:hover { transform: translateY(-4px); }
    .stat-card .card-body { display: flex; align-items: center; }
    .stat-card .fa { font-size: 2rem; margin-right: .75rem; }
    .stat-number { font-size: 2.25rem; margin: 0; }
    .stat-label { color: #666; font-size: .875rem; }
    .menu {
      background: #fff; border-radius: .5rem; padding: 1rem;
      box-shadow: 0 .125rem .25rem rgba(0,0,0,.075); margin-top: 1.5rem;
    }
    .menu .nav-link {
      color: #333; margin-bottom: .5rem; border-radius: .25rem;
    }
    .menu .nav-link.active,
    .menu .nav-link:hover {
      background: #007bff; color: #fff;
    }
  </style>
</head>
<body>

  <div class="page-wrapper">
    <?php include_once('inc/menu.php'); ?>

    <div class="page-content">
      <div class="inner-container">

        <!-- Breadcrumb + Search -->
        <section class="au-breadcrumb2 mb-4">
          <div class="d-flex justify-content-between align-items-center">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb mb-0 bg-transparent p-0">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Admin Dashboard</li>
              </ol>
            </nav>
            <?php include_once('inc/invoice_search.php'); ?>
          </div>
          <?php if (!empty($comment)) echo '<div class="mt-2">'.$comment.'</div>'; ?>
        </section>

        <!-- Announcement -->
        <div class="announcement text-center">
          <strong>Welcome!</strong> Manage receipts efficiently and keep track of your transactions.
        </div>

        <!-- KPI Cards -->
        <div class="row">
          <div class="col-md-3 mb-4">
            <div class="card stat-card">
              <div class="card-body">
                <i class="fa fa-file-invoice text-primary"></i>
                <div>
                  <p class="stat-number"><?= $num_invoices_all ?></p>
                  <p class="stat-label">Total Receipts</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-4">
            <div class="card stat-card">
              <div class="card-body">
                <i class="fa fa-check-circle text-success"></i>
                <div>
                  <p class="stat-number"><?= $num_invoices_paid ?></p>
                  <p class="stat-label">Full Payments</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-4">
            <div class="card stat-card">
              <div class="card-body">
                <i class="fa fa-hourglass-half text-warning"></i>
                <div>
                  <p class="stat-number"><?= $num_invoices_unpaid ?></p>
                  <p class="stat-label">Installment Payments</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-4">
            <div class="card stat-card">
              <div class="card-body">
                <i class="fa fa-users text-info"></i>
                <div>
                  <p class="stat-number"><?= $num_admin ?></p>
                  <p class="stat-label">Total Users</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Sidebar Menu -->
        <div class="row">
          <div class="col-12">
            <div class="menu">
              <ul class="nav flex-column">
                <li class="nav-item">
                  <a class="nav-link active" href="#">Menu</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="newreceipt.php">Generate new receipt</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="view_all_receipts.php">View receipts</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="edit_receipt_all.php">Edit receipts</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="delete_receipt_all.php">Delete receipt</a>
                </li>
				<li class="nav-item">
                  <a class="nav-link" href="signature_manager.php">Signature manager</a>
                </li>
              </ul>
            </div>
          </div>
        </div>

       <!-- Charts Row -->
<div class="row mb-4 d-flex align-items-stretch">
  <!-- 30-Day Line Chart -->
  <div class="col-md-6 mb-3 d-flex">
    <div class="card stat-card flex-fill">
      <div class="card-header">Receipts (Last 30 Days)</div>
      <div class="card-body">
        <canvas id="chartReceipts30" height="120"></canvas>
      </div>
    </div>
  </div>

  <!-- Doughnut Chart: Payment Type Split -->
  <div class="col-md-6 mb-3 d-flex">
    <div class="card stat-card flex-fill">
      <div class="card-header">Payment Type Distribution</div>
      <div class="card-body">
        <canvas id="chartPaymentType" height="120"></canvas>
      </div>
    </div>
  </div>
</div>


        <!-- Footer -->
        <div class="row mt-4">
          <div class="col-12">
            <?php include_once('inc/footer.php'); ?>
          </div>
        </div>

      </div><!-- /.inner-container -->
    </div><!-- /.page-content -->
  </div><!-- /.page-wrapper -->

  <!-- 1) jQuery core -->
  <script src="vendor/jquery-3.2.1.min.js"></script>
  <!-- 2) jQuery UI -->
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
  <!-- 3) Bootstrap JS -->
  <script src="vendor/bootstrap-4.1/popper.min.js"></script>
  <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
  <!-- 4) Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    // Line Chart (30 days)
    new Chart(document.getElementById('chartReceipts30'), {
      type: 'line',
      data: {
        labels: <?= json_encode($dates_last_30) ?>,
        datasets: [{
          label: 'Receipts',
          data: <?= json_encode($counts_last_30) ?>,
          fill: false,
          borderColor: '#007bff',
          tension: 0.3
        }]
      },
      options: {
        scales: { y: { beginAtZero: true }},
        plugins: { legend: { display: false }}
      }
    });

    // Doughnut Chart (payment split)
    new Chart(document.getElementById('chartPaymentType'), {
      type: 'doughnut',
      data: {
        labels: ['Full Payments', 'Installments'],
        datasets: [{
          data: [<?= $num_invoices_paid ?>, <?= $num_invoices_unpaid ?>],
          backgroundColor: ['#28a745','#ffc107']
        }]
      },
      options: {
        plugins: { legend: { position: 'bottom' } }
      }
    });
  </script>

  <!-- 5) Autocomplete -->
  <script>
    $(function(){
      $("#searchInput").autocomplete({
        source: function(request, response) {
          $.getJSON("search_receipt.php", { term: request.term }, response);
        },
        minLength: 2,
        select: function(event, ui) {
          window.location.href = "view_receipt.php?prefix_receipt_number="
                                + encodeURIComponent(ui.item.enc);
          return false;
        }
      });
    });
  </script>
</body>
</html>
