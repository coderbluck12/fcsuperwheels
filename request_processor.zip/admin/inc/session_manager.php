<?php
session_start();
include_once('inc/functions.php');
if(isset($_SESSION['current_user']))
{
  $username = $_SESSION['current_user'];

  // Prepare the query with placeholders
  $query_details = "SELECT * FROM `user` WHERE `username` = :username";
  $stmt = $pdo->prepare($query_details);

  // Bind the parameter
  $stmt->bindParam(':username', $username);

  // Execute the query
  $stmt->execute();

  // Fetch the results
  $result = $stmt->fetch(PDO::FETCH_ASSOC);

  if($result)
  {
    $admin_id = $result['id'];
    $admin_email = $result['email'];
    $admin_lastname = $result['lastname'];
    $admin_firstname = $result['firstname'];
    $admin_level = $result['level'];
    $full_name = $admin_lastname.', '.$admin_firstname;
    $full_name = ucwords($full_name);
  }
  else
  {
    header('Location:../');
  }
}
else
{
  header('Location:../');
}
?>

