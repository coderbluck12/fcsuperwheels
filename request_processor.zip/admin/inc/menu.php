<!-- HEADER DESKTOP-->
<header class="header-desktop3 d-none d-lg-block">
    <div class="section__content section__content--p35">
        <div class="header3-wrap">
            <div class="header__logo">
                <a href="dashboard.php">
                    <img src="sp_logo2.png" alt="CoolAdmin" width="60%" />
                </a>
            </div>
            <div class="header__navbar">
                <ul class="list-unstyled">
                    <li class="has-sub">
                        <a href="dashboard.php">
                            <i class="fas fa-tachometer-alt"></i>Home
                            <span class="bot-line"></span>
                        </a>
                    </li>
                    <li><a href="newreceipt.php"><i class="fa fa-edit"></i>Generate new receipt</a></li>
                    <li><a href="view_all_receipts.php"><i class="fa fa-credit-card"></i>View all receipts</a></li>
                    <li><a href="edit_receipt_all.php"><i class="fa fa-book"></i>Edit receipts</a></li>
                    <li><a href="delete_receipt_all.php"><i class="fa fa-trash"></i>Delete receipts</a></li>
                 <li>
  <a href="signature_manager.php">
    <i class="fa fa-arrow-up"></i> Signature Manager
  </a>
</li>
                    
                </ul>
            </div>
            <div class="header__tool">
                <span class="has-sub" style="color:white;">
                    <a href="logout.php" style="color:white;">
                        <i class="zmdi zmdi-power"></i> Log out
                    </a>
                </span>
            </div>
        </div>
    </div>
</header>

<!-- MOBILE NAVBAR (Collapsed) -->
<nav class="navbar navbar-expand-lg navbar-light bg-light d-block d-lg-none">

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
	
            <li class="nav-item">
			
                <a class="nav-link" href="newreceipt.php"><i class="fa fa-edit"></i> Generate new receipt</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_all_receipts.php"><i class="fa fa-credit-card"></i> View all receipts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="edit_receipt_all.php"><i class="fa fa-book"></i> Edit receipts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="delete_receipt_all.php"><i class="fa fa-trash"></i> Delete receipts</a>
            </li>
			<li class="nav-item">
  <a class="nav-link" href="signature_manager.php">
    <i class="fa fa-arrow-up"></i> Signature Manager
  </a>
</li>

            <li class="nav-item">
                <a class="nav-link" href="logout.php"><i class="zmdi zmdi-power"></i> Log out</a>
            </li>
        </ul>
    </div>
	<a href="#" class="float-right" style="text-align:right;">
                    <img src="sp_logo.png" alt="CoolAdmin" width="60%" />
                </a>
</nav>