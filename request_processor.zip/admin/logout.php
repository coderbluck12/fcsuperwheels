<?php
session_start();
@session_destroy();
unset($_SESSION['current_user']);
header("location:index.php");
?>